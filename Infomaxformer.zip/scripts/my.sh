python -u main.py --model infomaxformer --data ECL --features M --seq_len 784 --label_len 48 --pred_len 24 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ECL --features M --seq_len 784 --label_len 96 --pred_len 48 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ECL --features M --seq_len 784 --label_len 192 --pred_len 96 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ECL --features M --seq_len 784 --label_len 384 --pred_len 192 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ECL --features M --seq_len 784 --label_len 768 --pred_len 384 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10

python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 784 --label_len 48 --pred_len 24 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 784 --label_len 96 --pred_len 48 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 784 --label_len 192 --pred_len 96 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 784 --label_len 384 --pred_len 192 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 784 --label_len 768 --pred_len 384 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10

python -u main.py --model infomaxformer --data ETTh2 --features M --seq_len 784 --label_len 48 --pred_len 24 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 5 --moving_avg 25
python -u main.py --model infomaxformer --data ETTh2 --features M --seq_len 784 --label_len 96 --pred_len 48 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10 --moving_avg 25
python -u main.py --model infomaxformer --data ETTh2 --features M --seq_len 784 --label_len 192 --pred_len 96 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ETTh2 --features M --seq_len 784 --label_len 384 --pred_len 192 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ETTh2 --features M --seq_len 784 --label_len 768 --pred_len 384 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10

python -u main.py --model infomaxformer --data ETTm1 --features M --seq_len 784 --label_len 48 --pred_len 24 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ETTm1 --features M --seq_len 784 --label_len 96 --pred_len 48 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data ETTm1 --features M --seq_len 784 --label_len 192 --pred_len 96 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10 --moving_avg 73
python -u main.py --model infomaxformer --data ETTm1 --features M --seq_len 784 --label_len 384 --pred_len 192 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10 --moving_avg 73
python -u main.py --model infomaxformer --data ETTm1 --features M --seq_len 784 --label_len 768 --pred_len 384 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10 --moving_avg 73

python -u main.py --model infomaxformer --data WTH --features M --seq_len 784 --label_len 48 --pred_len 24 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10  --moving_avg 25
python -u main.py --model infomaxformer --data WTH --features M --seq_len 784 --label_len 96 --pred_len 48 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data WTH --features M --seq_len 784 --label_len 192 --pred_len 96 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data WTH --features M --seq_len 784 --label_len 384 --pred_len 192 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10
python -u main.py --model infomaxformer --data WTH --features M --seq_len 784 --label_len 768 --pred_len 384 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 10





python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 744 --label_len 48 --pred_len 768 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 1
python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 744 --label_len 48 --pred_len 960 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 1
python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 744 --label_len 48 --pred_len 1200 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 1
python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 744 --label_len 48 --pred_len 1440 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 1
python -u main.py --model infomaxformer --data ETTh1 --features M --seq_len 744 --label_len 48 --pred_len 1680 --e_layers 3 --d_layers 2 --attn sparse --des 'Exp' --itr 1

